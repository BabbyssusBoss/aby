

<!doctype html>
<html lang="fr">
<head>
	<meta charset="utf-8">
	<meta name=viewport content="width=device-width, initial-scale=1">
	<meta name="google-site-verification" content="WjxTbNFrIATvcSbPehUsujP2c62qwG_Ctj5Op1Jp2Sw" />
	<meta property="og:url"                content="https://www.abyssus.games/" />
<meta property="og:type"               content="website" />
<meta property="og:title"              content="Abyssus" />
<meta property="og:description"        content="Abyssus est un jeu de stratégie où vous controlez la faune marine. Confronté à des milliers d'autres joueurs et aux prédateurs sauvages, il vous faudra une armée puissante et de fidèles alliés pour dominer ces eaux." />
<meta property="og:image"              content="https://www.abyssus.games/facebook_partage.jpg" />
<meta property="og:locale" content="fr_FR" />
<meta property="og:image:width" content="1200" />

<meta property="og:image:height" content="630" />
	
	<title>Abyssus - MMORPG Gratuit en Ligne</title>
    <link href="favicon.ico" rel="icon" type="image/x-icon" />
	<link href="jquery-ui.css" rel="stylesheet">
    <link href="style-index2.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Bangers%7CAnton" rel="stylesheet"> 
    
    <link rel="stylesheet" href="flipclock/flipclock.css">
    <link rel="alternate" hreflang="fr-be, fr-ca" href="alternateURL">
    
	<script src="external/jquery/jquery.js"></script>
<script src="jquery-ui.js"></script>
<script src="external/sha512.js"></script>

<script src="flipclock/flipclock.js"></script>

</head>
<body>
<div id="hauttel"><img src="images/bantel.jpg" style="height: auto; width: 100%" alt="banniere"></div>
<div id="haut"></div>

<div id="menu">
	
	<a href="index.php"><div class="onglet">SE CONNECTER</div></a>
	<a href="index.php?page=inscription"><div class="onglet">Inscription</div></a>
	<a href="index.php?page=abyssus"><div class="onglet">Abyssus c'est quoi ?</div></a>
	<a href="index.php?page=equipe"><div class="onglet">L'équipe du jeu</div></a>
	<a href="http://forum.abyssus.games" target="_blank"><div class="onglet">Forum</div></a>
	
	<div style="clear: both;"></div>
	
	
</div>




<div id="infostats"><span style="font-family: 'Bangers', cursive;">Activité sur le jeu :</span><br/><img src="images/france.png" height="20" alt="France" style="vertical-align: bottom;"> S1 : <span id="total_joueur_s1"></span> joueurs dont <span id="total_joueur_online_s1"></span> en ligne</div>

<div id="bas">
	
	
	<div id="contenu" style="text-align: center;">
		
		

<h1>Bienvenue sur Abyssus</h1>

<p>Abyssus est un jeu de stratégie où vous controlez la faune marine.</p>

<p>Confronté à des milliers d'autres joueurs et aux prédateurs sauvages, il vous faudra une armée puissante et de fidèles alliés pour dominer ces eaux.</p>





<div id="divlogin" style="text-align: center;"><img src="images/shark.png" alt="requin" style="float: left; height: 300px;" class="masque">
<h2>Plonger dans le jeu</h2>







<form action="index.php" method="post" id="form">

<table style="width: 50%; border:0px;" id="tableaulogin">
  <tr>
    <td class="right">Océan :</td>
    <td class="left">    <select name="serveur" id="serveur">
      <option value="1">Océan 1</option>
         <option value="0">Serveur Test</option>
          </select></td>
  </tr>
  <tr>
    <td class="right">Pseudo :</td>
    <td class="left"><input type="text" name="login" id="pseudo"></td>
  </tr>
  <tr>
    <td class="right">Password :</td>
    <td class="left"><input type="password" name="password" id="pass1"> <input type="hidden" name="password2" value="" id="pass2"></td>
  </tr>
  <tr>
    <td colspan="2" class="center2"><br/><button id="login">Plonger</button></td>
    </tr>
  <tr>
    <td colspan="2" class="right2"><br/><a href="index.php?page=password_perdu">Mot de passe perdu ?</a></td>
  </tr>
</table>


</form></div>
<br/>



	
</div>
	
<div id="footer">- Copyright © 2017-2019 <a href="index.php">abyssus.games</a> - Tous droits réservés - <a href="index.php?page=mentionlegales">Mentions légales</a> - <a href="index.php?page=cgv">CGV</a> - <a href="index.php?page=cgu" target="_blank">CGU</a> - 
</div>	
</div>

<script>

$.post('total_joueur.php', {serveur:1, type:'total'}, function(data){$('#total_joueur_s1').html(data);});
$.post('total_joueur.php', {serveur:1, type:'online'}, function(data){$('#total_joueur_online_s1').html(data);});

$('#login').button().click(function(){

var serveur = $('#serveur').val();

if (serveur == 1) { var lien = 'https://s1.abyssus.games/';}
else if (serveur == 0) { var lien = 'https://test.abyssus.games/';}

$('#form').attr('action', lien);
	
	var token = '717f9ee7ab822a8c8a82b0cb318bc2d5';
	var hash = CryptoJS.SHA512($("#pass1").val()); 
	var hash2 = CryptoJS.SHA512(hash+token);
	$("#pass2").val(hash2); 
	
	//$("#pass1").val('');
	
$("#form").submit();

	
	});
	


$('.button')
  .button()
  .css({
          'font' : 'inherit',
         'color' : '#006',
    'text-align' : 'left',
       'outline' : 'none',
        'cursor' : 'text'
  });
  
  $( "#serveur" ).selectmenu({});


</script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112072554-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112072554-1');
</script>


</body>
</html>
